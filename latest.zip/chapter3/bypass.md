No Task Project.   
Bypass = True, chapter 3
