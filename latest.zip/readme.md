### Hello! 👋

[text save]   
plt.axvline(-1.65, color="red", linestyle="--")   
from statsmodels.stats.proportion import proportions_ztest   
plt.rc('font', family='Malgun Gothic')


[default Code]   
alpha = 0.05
if p_value < alpha:   
    print(f"p-value는 {p_value:.4f}로, 유의 수준 {alpha}보다 작다.\n따라서 귀무 가설을 기각한다.")    
else:
    print(f"p-value는 {p_value:.4f}로, 유의 수준 {alpha}보다 크거나 같다.\n따라서 귀무 가설을 기각할 수 없음")   
